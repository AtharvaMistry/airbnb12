import './App.css';
import AlarmClock from './components/alarmClock';

function App() {
  return (
    <div className="App">
      <AlarmClock/>
    </div>
  );
}

export default App;
